--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 13.5
-- Dumped by pg_dump version 13.5

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE lims_db;
--
-- Name: lims_db; Type: DATABASE; Schema: -; Owner: sa
--

CREATE DATABASE lims_db WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'en_US.utf8';


ALTER DATABASE lims_db OWNER TO sa;

\connect lims_db

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: accounts_client; Type: TABLE; Schema: public; Owner: sa
--

CREATE TABLE public.accounts_client (
    id bigint NOT NULL,
    company_name character varying(100) NOT NULL,
    contact_person character varying(100) NOT NULL,
    phone_number character varying(10) NOT NULL,
    address character varying(200) NOT NULL,
    user_id integer NOT NULL,
    account_number integer NOT NULL
);


ALTER TABLE public.accounts_client OWNER TO sa;

--
-- Name: accounts_client_id_seq; Type: SEQUENCE; Schema: public; Owner: sa
--

CREATE SEQUENCE public.accounts_client_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.accounts_client_id_seq OWNER TO sa;

--
-- Name: accounts_client_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: sa
--

ALTER SEQUENCE public.accounts_client_id_seq OWNED BY public.accounts_client.id;


--
-- Name: accounts_labadmin; Type: TABLE; Schema: public; Owner: sa
--

CREATE TABLE public.accounts_labadmin (
    id bigint NOT NULL,
    job_title character varying(100) NOT NULL,
    user_id integer NOT NULL
);


ALTER TABLE public.accounts_labadmin OWNER TO sa;

--
-- Name: accounts_labadmin_id_seq; Type: SEQUENCE; Schema: public; Owner: sa
--

CREATE SEQUENCE public.accounts_labadmin_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.accounts_labadmin_id_seq OWNER TO sa;

--
-- Name: accounts_labadmin_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: sa
--

ALTER SEQUENCE public.accounts_labadmin_id_seq OWNED BY public.accounts_labadmin.id;


--
-- Name: accounts_labworker; Type: TABLE; Schema: public; Owner: sa
--

CREATE TABLE public.accounts_labworker (
    id bigint NOT NULL,
    job_title character varying(100) NOT NULL,
    user_id integer NOT NULL
);


ALTER TABLE public.accounts_labworker OWNER TO sa;

--
-- Name: accounts_labworker_id_seq; Type: SEQUENCE; Schema: public; Owner: sa
--

CREATE SEQUENCE public.accounts_labworker_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.accounts_labworker_id_seq OWNER TO sa;

--
-- Name: accounts_labworker_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: sa
--

ALTER SEQUENCE public.accounts_labworker_id_seq OWNED BY public.accounts_labworker.id;


--
-- Name: auth_group; Type: TABLE; Schema: public; Owner: sa
--

CREATE TABLE public.auth_group (
    id integer NOT NULL,
    name character varying(150) NOT NULL
);


ALTER TABLE public.auth_group OWNER TO sa;

--
-- Name: auth_group_id_seq; Type: SEQUENCE; Schema: public; Owner: sa
--

CREATE SEQUENCE public.auth_group_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_group_id_seq OWNER TO sa;

--
-- Name: auth_group_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: sa
--

ALTER SEQUENCE public.auth_group_id_seq OWNED BY public.auth_group.id;


--
-- Name: auth_group_permissions; Type: TABLE; Schema: public; Owner: sa
--

CREATE TABLE public.auth_group_permissions (
    id bigint NOT NULL,
    group_id integer NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE public.auth_group_permissions OWNER TO sa;

--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: sa
--

CREATE SEQUENCE public.auth_group_permissions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_group_permissions_id_seq OWNER TO sa;

--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: sa
--

ALTER SEQUENCE public.auth_group_permissions_id_seq OWNED BY public.auth_group_permissions.id;


--
-- Name: auth_permission; Type: TABLE; Schema: public; Owner: sa
--

CREATE TABLE public.auth_permission (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    content_type_id integer NOT NULL,
    codename character varying(100) NOT NULL
);


ALTER TABLE public.auth_permission OWNER TO sa;

--
-- Name: auth_permission_id_seq; Type: SEQUENCE; Schema: public; Owner: sa
--

CREATE SEQUENCE public.auth_permission_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_permission_id_seq OWNER TO sa;

--
-- Name: auth_permission_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: sa
--

ALTER SEQUENCE public.auth_permission_id_seq OWNED BY public.auth_permission.id;


--
-- Name: auth_user; Type: TABLE; Schema: public; Owner: sa
--

CREATE TABLE public.auth_user (
    id integer NOT NULL,
    password character varying(128) NOT NULL,
    last_login timestamp with time zone,
    is_superuser boolean NOT NULL,
    username character varying(150) NOT NULL,
    first_name character varying(150) NOT NULL,
    last_name character varying(150) NOT NULL,
    email character varying(254) NOT NULL,
    is_staff boolean NOT NULL,
    is_active boolean NOT NULL,
    date_joined timestamp with time zone NOT NULL
);


ALTER TABLE public.auth_user OWNER TO sa;

--
-- Name: auth_user_groups; Type: TABLE; Schema: public; Owner: sa
--

CREATE TABLE public.auth_user_groups (
    id bigint NOT NULL,
    user_id integer NOT NULL,
    group_id integer NOT NULL
);


ALTER TABLE public.auth_user_groups OWNER TO sa;

--
-- Name: auth_user_groups_id_seq; Type: SEQUENCE; Schema: public; Owner: sa
--

CREATE SEQUENCE public.auth_user_groups_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_user_groups_id_seq OWNER TO sa;

--
-- Name: auth_user_groups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: sa
--

ALTER SEQUENCE public.auth_user_groups_id_seq OWNED BY public.auth_user_groups.id;


--
-- Name: auth_user_id_seq; Type: SEQUENCE; Schema: public; Owner: sa
--

CREATE SEQUENCE public.auth_user_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_user_id_seq OWNER TO sa;

--
-- Name: auth_user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: sa
--

ALTER SEQUENCE public.auth_user_id_seq OWNED BY public.auth_user.id;


--
-- Name: auth_user_user_permissions; Type: TABLE; Schema: public; Owner: sa
--

CREATE TABLE public.auth_user_user_permissions (
    id bigint NOT NULL,
    user_id integer NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE public.auth_user_user_permissions OWNER TO sa;

--
-- Name: auth_user_user_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: sa
--

CREATE SEQUENCE public.auth_user_user_permissions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_user_user_permissions_id_seq OWNER TO sa;

--
-- Name: auth_user_user_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: sa
--

ALTER SEQUENCE public.auth_user_user_permissions_id_seq OWNED BY public.auth_user_user_permissions.id;


--
-- Name: django_admin_log; Type: TABLE; Schema: public; Owner: sa
--

CREATE TABLE public.django_admin_log (
    id integer NOT NULL,
    action_time timestamp with time zone NOT NULL,
    object_id text,
    object_repr character varying(200) NOT NULL,
    action_flag smallint NOT NULL,
    change_message text NOT NULL,
    content_type_id integer,
    user_id integer NOT NULL,
    CONSTRAINT django_admin_log_action_flag_check CHECK ((action_flag >= 0))
);


ALTER TABLE public.django_admin_log OWNER TO sa;

--
-- Name: django_admin_log_id_seq; Type: SEQUENCE; Schema: public; Owner: sa
--

CREATE SEQUENCE public.django_admin_log_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_admin_log_id_seq OWNER TO sa;

--
-- Name: django_admin_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: sa
--

ALTER SEQUENCE public.django_admin_log_id_seq OWNED BY public.django_admin_log.id;


--
-- Name: django_content_type; Type: TABLE; Schema: public; Owner: sa
--

CREATE TABLE public.django_content_type (
    id integer NOT NULL,
    app_label character varying(100) NOT NULL,
    model character varying(100) NOT NULL
);


ALTER TABLE public.django_content_type OWNER TO sa;

--
-- Name: django_content_type_id_seq; Type: SEQUENCE; Schema: public; Owner: sa
--

CREATE SEQUENCE public.django_content_type_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_content_type_id_seq OWNER TO sa;

--
-- Name: django_content_type_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: sa
--

ALTER SEQUENCE public.django_content_type_id_seq OWNED BY public.django_content_type.id;


--
-- Name: django_migrations; Type: TABLE; Schema: public; Owner: sa
--

CREATE TABLE public.django_migrations (
    id bigint NOT NULL,
    app character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    applied timestamp with time zone NOT NULL
);


ALTER TABLE public.django_migrations OWNER TO sa;

--
-- Name: django_migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: sa
--

CREATE SEQUENCE public.django_migrations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_migrations_id_seq OWNER TO sa;

--
-- Name: django_migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: sa
--

ALTER SEQUENCE public.django_migrations_id_seq OWNED BY public.django_migrations.id;


--
-- Name: django_session; Type: TABLE; Schema: public; Owner: sa
--

CREATE TABLE public.django_session (
    session_key character varying(40) NOT NULL,
    session_data text NOT NULL,
    expire_date timestamp with time zone NOT NULL
);


ALTER TABLE public.django_session OWNER TO sa;

--
-- Name: laboratoryOrders_labsample; Type: TABLE; Schema: public; Owner: sa
--

CREATE TABLE public."laboratoryOrders_labsample" (
    id bigint NOT NULL,
    lab_location_id bigint NOT NULL,
    sample_id bigint NOT NULL
);


ALTER TABLE public."laboratoryOrders_labsample" OWNER TO sa;

--
-- Name: laboratoryOrders_labsample_id_seq; Type: SEQUENCE; Schema: public; Owner: sa
--

CREATE SEQUENCE public."laboratoryOrders_labsample_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."laboratoryOrders_labsample_id_seq" OWNER TO sa;

--
-- Name: laboratoryOrders_labsample_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: sa
--

ALTER SEQUENCE public."laboratoryOrders_labsample_id_seq" OWNED BY public."laboratoryOrders_labsample".id;


--
-- Name: laboratoryOrders_ordersample; Type: TABLE; Schema: public; Owner: sa
--

CREATE TABLE public."laboratoryOrders_ordersample" (
    id bigint NOT NULL,
    order_id bigint NOT NULL,
    sample_id bigint NOT NULL
);


ALTER TABLE public."laboratoryOrders_ordersample" OWNER TO sa;

--
-- Name: laboratoryOrders_ordersample_id_seq; Type: SEQUENCE; Schema: public; Owner: sa
--

CREATE SEQUENCE public."laboratoryOrders_ordersample_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."laboratoryOrders_ordersample_id_seq" OWNER TO sa;

--
-- Name: laboratoryOrders_ordersample_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: sa
--

ALTER SEQUENCE public."laboratoryOrders_ordersample_id_seq" OWNED BY public."laboratoryOrders_ordersample".id;


--
-- Name: laboratoryOrders_ordertest; Type: TABLE; Schema: public; Owner: sa
--

CREATE TABLE public."laboratoryOrders_ordertest" (
    id bigint NOT NULL,
    order_number_id bigint NOT NULL,
    test_id_id bigint
);


ALTER TABLE public."laboratoryOrders_ordertest" OWNER TO sa;

--
-- Name: laboratoryOrders_ordertest_id_seq; Type: SEQUENCE; Schema: public; Owner: sa
--

CREATE SEQUENCE public."laboratoryOrders_ordertest_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."laboratoryOrders_ordertest_id_seq" OWNER TO sa;

--
-- Name: laboratoryOrders_ordertest_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: sa
--

ALTER SEQUENCE public."laboratoryOrders_ordertest_id_seq" OWNED BY public."laboratoryOrders_ordertest".id;


--
-- Name: laboratoryOrders_sample; Type: TABLE; Schema: public; Owner: sa
--

CREATE TABLE public."laboratoryOrders_sample" (
    id bigint NOT NULL,
    sample_type character varying(100) NOT NULL,
    sample_form character varying(100) NOT NULL,
    sop_number character varying(100) NOT NULL,
    lab_personel_id bigint NOT NULL
);


ALTER TABLE public."laboratoryOrders_sample" OWNER TO sa;

--
-- Name: laboratoryOrders_sample_id_seq; Type: SEQUENCE; Schema: public; Owner: sa
--

CREATE SEQUENCE public."laboratoryOrders_sample_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."laboratoryOrders_sample_id_seq" OWNER TO sa;

--
-- Name: laboratoryOrders_sample_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: sa
--

ALTER SEQUENCE public."laboratoryOrders_sample_id_seq" OWNED BY public."laboratoryOrders_sample".id;


--
-- Name: laboratoryOrders_testpackage; Type: TABLE; Schema: public; Owner: sa
--

CREATE TABLE public."laboratoryOrders_testpackage" (
    id bigint NOT NULL,
    package_id bigint NOT NULL,
    test_id bigint NOT NULL
);


ALTER TABLE public."laboratoryOrders_testpackage" OWNER TO sa;

--
-- Name: laboratoryOrders_testpackage_id_seq; Type: SEQUENCE; Schema: public; Owner: sa
--

CREATE SEQUENCE public."laboratoryOrders_testpackage_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."laboratoryOrders_testpackage_id_seq" OWNER TO sa;

--
-- Name: laboratoryOrders_testpackage_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: sa
--

ALTER SEQUENCE public."laboratoryOrders_testpackage_id_seq" OWNED BY public."laboratoryOrders_testpackage".id;


--
-- Name: laboratoryOrders_testresult; Type: TABLE; Schema: public; Owner: sa
--

CREATE TABLE public."laboratoryOrders_testresult" (
    id bigint NOT NULL,
    status character varying(50) NOT NULL,
    result character varying(200) NOT NULL,
    test_id_id bigint NOT NULL
);


ALTER TABLE public."laboratoryOrders_testresult" OWNER TO sa;

--
-- Name: laboratoryOrders_testresult_id_seq; Type: SEQUENCE; Schema: public; Owner: sa
--

CREATE SEQUENCE public."laboratoryOrders_testresult_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."laboratoryOrders_testresult_id_seq" OWNER TO sa;

--
-- Name: laboratoryOrders_testresult_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: sa
--

ALTER SEQUENCE public."laboratoryOrders_testresult_id_seq" OWNED BY public."laboratoryOrders_testresult".id;


--
-- Name: laboratoryOrders_testsample; Type: TABLE; Schema: public; Owner: sa
--

CREATE TABLE public."laboratoryOrders_testsample" (
    id bigint NOT NULL,
    lab_sample_id_id bigint NOT NULL,
    test_id bigint NOT NULL
);


ALTER TABLE public."laboratoryOrders_testsample" OWNER TO sa;

--
-- Name: laboratoryOrders_testsample_id_seq; Type: SEQUENCE; Schema: public; Owner: sa
--

CREATE SEQUENCE public."laboratoryOrders_testsample_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."laboratoryOrders_testsample_id_seq" OWNER TO sa;

--
-- Name: laboratoryOrders_testsample_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: sa
--

ALTER SEQUENCE public."laboratoryOrders_testsample_id_seq" OWNED BY public."laboratoryOrders_testsample".id;


--
-- Name: laboratory_instrument; Type: TABLE; Schema: public; Owner: sa
--

CREATE TABLE public.laboratory_instrument (
    id bigint NOT NULL,
    type character varying(100) NOT NULL,
    location_id bigint NOT NULL
);


ALTER TABLE public.laboratory_instrument OWNER TO sa;

--
-- Name: laboratory_instrument_id_seq; Type: SEQUENCE; Schema: public; Owner: sa
--

CREATE SEQUENCE public.laboratory_instrument_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.laboratory_instrument_id_seq OWNER TO sa;

--
-- Name: laboratory_instrument_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: sa
--

ALTER SEQUENCE public.laboratory_instrument_id_seq OWNED BY public.laboratory_instrument.id;


--
-- Name: laboratory_inventoryitem; Type: TABLE; Schema: public; Owner: sa
--

CREATE TABLE public.laboratory_inventoryitem (
    id bigint NOT NULL,
    status character varying(50) NOT NULL,
    quantity_unit character varying(10) NOT NULL,
    usage_rate_unit character varying(10) NOT NULL,
    type character varying(50) NOT NULL,
    estimated_need integer NOT NULL,
    estimated_quantity integer NOT NULL,
    usage_rate integer NOT NULL
);


ALTER TABLE public.laboratory_inventoryitem OWNER TO sa;

--
-- Name: laboratory_inventoryitem_id_seq; Type: SEQUENCE; Schema: public; Owner: sa
--

CREATE SEQUENCE public.laboratory_inventoryitem_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.laboratory_inventoryitem_id_seq OWNER TO sa;

--
-- Name: laboratory_inventoryitem_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: sa
--

ALTER SEQUENCE public.laboratory_inventoryitem_id_seq OWNED BY public.laboratory_inventoryitem.id;


--
-- Name: laboratory_location; Type: TABLE; Schema: public; Owner: sa
--

CREATE TABLE public.laboratory_location (
    id bigint NOT NULL,
    name character varying(100) NOT NULL,
    code character varying(100) NOT NULL
);


ALTER TABLE public.laboratory_location OWNER TO sa;

--
-- Name: laboratory_location_id_seq; Type: SEQUENCE; Schema: public; Owner: sa
--

CREATE SEQUENCE public.laboratory_location_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.laboratory_location_id_seq OWNER TO sa;

--
-- Name: laboratory_location_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: sa
--

ALTER SEQUENCE public.laboratory_location_id_seq OWNED BY public.laboratory_location.id;


--
-- Name: laboratory_test; Type: TABLE; Schema: public; Owner: sa
--

CREATE TABLE public.laboratory_test (
    id bigint NOT NULL,
    name character varying(100) NOT NULL,
    code character varying(100) NOT NULL,
    cost double precision NOT NULL,
    rush boolean NOT NULL,
    time_taken integer NOT NULL,
    sample_type character varying(100)
);


ALTER TABLE public.laboratory_test OWNER TO sa;

--
-- Name: laboratory_test_id_seq; Type: SEQUENCE; Schema: public; Owner: sa
--

CREATE SEQUENCE public.laboratory_test_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.laboratory_test_id_seq OWNER TO sa;

--
-- Name: laboratory_test_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: sa
--

ALTER SEQUENCE public.laboratory_test_id_seq OWNED BY public.laboratory_test.id;


--
-- Name: laboratory_testinstrument; Type: TABLE; Schema: public; Owner: sa
--

CREATE TABLE public.laboratory_testinstrument (
    id bigint NOT NULL,
    instrument_id bigint NOT NULL,
    test_id_id bigint NOT NULL
);


ALTER TABLE public.laboratory_testinstrument OWNER TO sa;

--
-- Name: laboratory_testinstrument_id_seq; Type: SEQUENCE; Schema: public; Owner: sa
--

CREATE SEQUENCE public.laboratory_testinstrument_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.laboratory_testinstrument_id_seq OWNER TO sa;

--
-- Name: laboratory_testinstrument_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: sa
--

ALTER SEQUENCE public.laboratory_testinstrument_id_seq OWNED BY public.laboratory_testinstrument.id;


--
-- Name: orders_order; Type: TABLE; Schema: public; Owner: sa
--

CREATE TABLE public.orders_order (
    id bigint NOT NULL,
    account_number_id bigint NOT NULL,
    order_number integer NOT NULL,
    submission_date date NOT NULL
);


ALTER TABLE public.orders_order OWNER TO sa;

--
-- Name: orders_order_id_seq; Type: SEQUENCE; Schema: public; Owner: sa
--

CREATE SEQUENCE public.orders_order_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.orders_order_id_seq OWNER TO sa;

--
-- Name: orders_order_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: sa
--

ALTER SEQUENCE public.orders_order_id_seq OWNED BY public.orders_order.id;


--
-- Name: orders_package; Type: TABLE; Schema: public; Owner: sa
--

CREATE TABLE public.orders_package (
    id bigint NOT NULL,
    name character varying(100) NOT NULL
);


ALTER TABLE public.orders_package OWNER TO sa;

--
-- Name: orders_package_id_seq; Type: SEQUENCE; Schema: public; Owner: sa
--

CREATE SEQUENCE public.orders_package_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.orders_package_id_seq OWNER TO sa;

--
-- Name: orders_package_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: sa
--

ALTER SEQUENCE public.orders_package_id_seq OWNED BY public.orders_package.id;


--
-- Name: training_training; Type: TABLE; Schema: public; Owner: sa
--

CREATE TABLE public.training_training (
    id bigint NOT NULL,
    name character varying(100) NOT NULL
);


ALTER TABLE public.training_training OWNER TO sa;

--
-- Name: training_training_id_seq; Type: SEQUENCE; Schema: public; Owner: sa
--

CREATE SEQUENCE public.training_training_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.training_training_id_seq OWNER TO sa;

--
-- Name: training_training_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: sa
--

ALTER SEQUENCE public.training_training_id_seq OWNED BY public.training_training.id;


--
-- Name: training_trainingattendence; Type: TABLE; Schema: public; Owner: sa
--

CREATE TABLE public.training_trainingattendence (
    id bigint NOT NULL,
    attendee_id bigint NOT NULL,
    training_instance_id bigint NOT NULL
);


ALTER TABLE public.training_trainingattendence OWNER TO sa;

--
-- Name: training_trainingattendence_id_seq; Type: SEQUENCE; Schema: public; Owner: sa
--

CREATE SEQUENCE public.training_trainingattendence_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.training_trainingattendence_id_seq OWNER TO sa;

--
-- Name: training_trainingattendence_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: sa
--

ALTER SEQUENCE public.training_trainingattendence_id_seq OWNED BY public.training_trainingattendence.id;


--
-- Name: training_trainingschedule; Type: TABLE; Schema: public; Owner: sa
--

CREATE TABLE public.training_trainingschedule (
    id bigint NOT NULL,
    training_type_id bigint NOT NULL,
    date_time timestamp with time zone NOT NULL
);


ALTER TABLE public.training_trainingschedule OWNER TO sa;

--
-- Name: training_trainingschedule_id_seq; Type: SEQUENCE; Schema: public; Owner: sa
--

CREATE SEQUENCE public.training_trainingschedule_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.training_trainingschedule_id_seq OWNER TO sa;

--
-- Name: training_trainingschedule_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: sa
--

ALTER SEQUENCE public.training_trainingschedule_id_seq OWNED BY public.training_trainingschedule.id;


--
-- Name: accounts_client id; Type: DEFAULT; Schema: public; Owner: sa
--

ALTER TABLE ONLY public.accounts_client ALTER COLUMN id SET DEFAULT nextval('public.accounts_client_id_seq'::regclass);


--
-- Name: accounts_labadmin id; Type: DEFAULT; Schema: public; Owner: sa
--

ALTER TABLE ONLY public.accounts_labadmin ALTER COLUMN id SET DEFAULT nextval('public.accounts_labadmin_id_seq'::regclass);


--
-- Name: accounts_labworker id; Type: DEFAULT; Schema: public; Owner: sa
--

ALTER TABLE ONLY public.accounts_labworker ALTER COLUMN id SET DEFAULT nextval('public.accounts_labworker_id_seq'::regclass);


--
-- Name: auth_group id; Type: DEFAULT; Schema: public; Owner: sa
--

ALTER TABLE ONLY public.auth_group ALTER COLUMN id SET DEFAULT nextval('public.auth_group_id_seq'::regclass);


--
-- Name: auth_group_permissions id; Type: DEFAULT; Schema: public; Owner: sa
--

ALTER TABLE ONLY public.auth_group_permissions ALTER COLUMN id SET DEFAULT nextval('public.auth_group_permissions_id_seq'::regclass);


--
-- Name: auth_permission id; Type: DEFAULT; Schema: public; Owner: sa
--

ALTER TABLE ONLY public.auth_permission ALTER COLUMN id SET DEFAULT nextval('public.auth_permission_id_seq'::regclass);


--
-- Name: auth_user id; Type: DEFAULT; Schema: public; Owner: sa
--

ALTER TABLE ONLY public.auth_user ALTER COLUMN id SET DEFAULT nextval('public.auth_user_id_seq'::regclass);


--
-- Name: auth_user_groups id; Type: DEFAULT; Schema: public; Owner: sa
--

ALTER TABLE ONLY public.auth_user_groups ALTER COLUMN id SET DEFAULT nextval('public.auth_user_groups_id_seq'::regclass);


--
-- Name: auth_user_user_permissions id; Type: DEFAULT; Schema: public; Owner: sa
--

ALTER TABLE ONLY public.auth_user_user_permissions ALTER COLUMN id SET DEFAULT nextval('public.auth_user_user_permissions_id_seq'::regclass);


--
-- Name: django_admin_log id; Type: DEFAULT; Schema: public; Owner: sa
--

ALTER TABLE ONLY public.django_admin_log ALTER COLUMN id SET DEFAULT nextval('public.django_admin_log_id_seq'::regclass);


--
-- Name: django_content_type id; Type: DEFAULT; Schema: public; Owner: sa
--

ALTER TABLE ONLY public.django_content_type ALTER COLUMN id SET DEFAULT nextval('public.django_content_type_id_seq'::regclass);


--
-- Name: django_migrations id; Type: DEFAULT; Schema: public; Owner: sa
--

ALTER TABLE ONLY public.django_migrations ALTER COLUMN id SET DEFAULT nextval('public.django_migrations_id_seq'::regclass);


--
-- Name: laboratoryOrders_labsample id; Type: DEFAULT; Schema: public; Owner: sa
--

ALTER TABLE ONLY public."laboratoryOrders_labsample" ALTER COLUMN id SET DEFAULT nextval('public."laboratoryOrders_labsample_id_seq"'::regclass);


--
-- Name: laboratoryOrders_ordersample id; Type: DEFAULT; Schema: public; Owner: sa
--

ALTER TABLE ONLY public."laboratoryOrders_ordersample" ALTER COLUMN id SET DEFAULT nextval('public."laboratoryOrders_ordersample_id_seq"'::regclass);


--
-- Name: laboratoryOrders_ordertest id; Type: DEFAULT; Schema: public; Owner: sa
--

ALTER TABLE ONLY public."laboratoryOrders_ordertest" ALTER COLUMN id SET DEFAULT nextval('public."laboratoryOrders_ordertest_id_seq"'::regclass);


--
-- Name: laboratoryOrders_sample id; Type: DEFAULT; Schema: public; Owner: sa
--

ALTER TABLE ONLY public."laboratoryOrders_sample" ALTER COLUMN id SET DEFAULT nextval('public."laboratoryOrders_sample_id_seq"'::regclass);


--
-- Name: laboratoryOrders_testpackage id; Type: DEFAULT; Schema: public; Owner: sa
--

ALTER TABLE ONLY public."laboratoryOrders_testpackage" ALTER COLUMN id SET DEFAULT nextval('public."laboratoryOrders_testpackage_id_seq"'::regclass);


--
-- Name: laboratoryOrders_testresult id; Type: DEFAULT; Schema: public; Owner: sa
--

ALTER TABLE ONLY public."laboratoryOrders_testresult" ALTER COLUMN id SET DEFAULT nextval('public."laboratoryOrders_testresult_id_seq"'::regclass);


--
-- Name: laboratoryOrders_testsample id; Type: DEFAULT; Schema: public; Owner: sa
--

ALTER TABLE ONLY public."laboratoryOrders_testsample" ALTER COLUMN id SET DEFAULT nextval('public."laboratoryOrders_testsample_id_seq"'::regclass);


--
-- Name: laboratory_instrument id; Type: DEFAULT; Schema: public; Owner: sa
--

ALTER TABLE ONLY public.laboratory_instrument ALTER COLUMN id SET DEFAULT nextval('public.laboratory_instrument_id_seq'::regclass);


--
-- Name: laboratory_inventoryitem id; Type: DEFAULT; Schema: public; Owner: sa
--

ALTER TABLE ONLY public.laboratory_inventoryitem ALTER COLUMN id SET DEFAULT nextval('public.laboratory_inventoryitem_id_seq'::regclass);


--
-- Name: laboratory_location id; Type: DEFAULT; Schema: public; Owner: sa
--

ALTER TABLE ONLY public.laboratory_location ALTER COLUMN id SET DEFAULT nextval('public.laboratory_location_id_seq'::regclass);


--
-- Name: laboratory_test id; Type: DEFAULT; Schema: public; Owner: sa
--

ALTER TABLE ONLY public.laboratory_test ALTER COLUMN id SET DEFAULT nextval('public.laboratory_test_id_seq'::regclass);


--
-- Name: laboratory_testinstrument id; Type: DEFAULT; Schema: public; Owner: sa
--

ALTER TABLE ONLY public.laboratory_testinstrument ALTER COLUMN id SET DEFAULT nextval('public.laboratory_testinstrument_id_seq'::regclass);


--
-- Name: orders_order id; Type: DEFAULT; Schema: public; Owner: sa
--

ALTER TABLE ONLY public.orders_order ALTER COLUMN id SET DEFAULT nextval('public.orders_order_id_seq'::regclass);


--
-- Name: orders_package id; Type: DEFAULT; Schema: public; Owner: sa
--

ALTER TABLE ONLY public.orders_package ALTER COLUMN id SET DEFAULT nextval('public.orders_package_id_seq'::regclass);


--
-- Name: training_training id; Type: DEFAULT; Schema: public; Owner: sa
--

ALTER TABLE ONLY public.training_training ALTER COLUMN id SET DEFAULT nextval('public.training_training_id_seq'::regclass);


--
-- Name: training_trainingattendence id; Type: DEFAULT; Schema: public; Owner: sa
--

ALTER TABLE ONLY public.training_trainingattendence ALTER COLUMN id SET DEFAULT nextval('public.training_trainingattendence_id_seq'::regclass);


--
-- Name: training_trainingschedule id; Type: DEFAULT; Schema: public; Owner: sa
--

ALTER TABLE ONLY public.training_trainingschedule ALTER COLUMN id SET DEFAULT nextval('public.training_trainingschedule_id_seq'::regclass);


--
-- Data for Name: accounts_client; Type: TABLE DATA; Schema: public; Owner: sa
--

COPY public.accounts_client (id, company_name, contact_person, phone_number, address, user_id, account_number) FROM stdin;
\.
COPY public.accounts_client (id, company_name, contact_person, phone_number, address, user_id, account_number) FROM '$$PATH$$/3352.dat';

--
-- Data for Name: accounts_labadmin; Type: TABLE DATA; Schema: public; Owner: sa
--

COPY public.accounts_labadmin (id, job_title, user_id) FROM stdin;
\.
COPY public.accounts_labadmin (id, job_title, user_id) FROM '$$PATH$$/3350.dat';

--
-- Data for Name: accounts_labworker; Type: TABLE DATA; Schema: public; Owner: sa
--

COPY public.accounts_labworker (id, job_title, user_id) FROM stdin;
\.
COPY public.accounts_labworker (id, job_title, user_id) FROM '$$PATH$$/3348.dat';

--
-- Data for Name: auth_group; Type: TABLE DATA; Schema: public; Owner: sa
--

COPY public.auth_group (id, name) FROM stdin;
\.
COPY public.auth_group (id, name) FROM '$$PATH$$/3338.dat';

--
-- Data for Name: auth_group_permissions; Type: TABLE DATA; Schema: public; Owner: sa
--

COPY public.auth_group_permissions (id, group_id, permission_id) FROM stdin;
\.
COPY public.auth_group_permissions (id, group_id, permission_id) FROM '$$PATH$$/3340.dat';

--
-- Data for Name: auth_permission; Type: TABLE DATA; Schema: public; Owner: sa
--

COPY public.auth_permission (id, name, content_type_id, codename) FROM stdin;
\.
COPY public.auth_permission (id, name, content_type_id, codename) FROM '$$PATH$$/3336.dat';

--
-- Data for Name: auth_user; Type: TABLE DATA; Schema: public; Owner: sa
--

COPY public.auth_user (id, password, last_login, is_superuser, username, first_name, last_name, email, is_staff, is_active, date_joined) FROM stdin;
\.
COPY public.auth_user (id, password, last_login, is_superuser, username, first_name, last_name, email, is_staff, is_active, date_joined) FROM '$$PATH$$/3342.dat';

--
-- Data for Name: auth_user_groups; Type: TABLE DATA; Schema: public; Owner: sa
--

COPY public.auth_user_groups (id, user_id, group_id) FROM stdin;
\.
COPY public.auth_user_groups (id, user_id, group_id) FROM '$$PATH$$/3344.dat';

--
-- Data for Name: auth_user_user_permissions; Type: TABLE DATA; Schema: public; Owner: sa
--

COPY public.auth_user_user_permissions (id, user_id, permission_id) FROM stdin;
\.
COPY public.auth_user_user_permissions (id, user_id, permission_id) FROM '$$PATH$$/3346.dat';

--
-- Data for Name: django_admin_log; Type: TABLE DATA; Schema: public; Owner: sa
--

COPY public.django_admin_log (id, action_time, object_id, object_repr, action_flag, change_message, content_type_id, user_id) FROM stdin;
\.
COPY public.django_admin_log (id, action_time, object_id, object_repr, action_flag, change_message, content_type_id, user_id) FROM '$$PATH$$/3354.dat';

--
-- Data for Name: django_content_type; Type: TABLE DATA; Schema: public; Owner: sa
--

COPY public.django_content_type (id, app_label, model) FROM stdin;
\.
COPY public.django_content_type (id, app_label, model) FROM '$$PATH$$/3334.dat';

--
-- Data for Name: django_migrations; Type: TABLE DATA; Schema: public; Owner: sa
--

COPY public.django_migrations (id, app, name, applied) FROM stdin;
\.
COPY public.django_migrations (id, app, name, applied) FROM '$$PATH$$/3332.dat';

--
-- Data for Name: django_session; Type: TABLE DATA; Schema: public; Owner: sa
--

COPY public.django_session (session_key, session_data, expire_date) FROM stdin;
\.
COPY public.django_session (session_key, session_data, expire_date) FROM '$$PATH$$/3383.dat';

--
-- Data for Name: laboratoryOrders_labsample; Type: TABLE DATA; Schema: public; Owner: sa
--

COPY public."laboratoryOrders_labsample" (id, lab_location_id, sample_id) FROM stdin;
\.
COPY public."laboratoryOrders_labsample" (id, lab_location_id, sample_id) FROM '$$PATH$$/3370.dat';

--
-- Data for Name: laboratoryOrders_ordersample; Type: TABLE DATA; Schema: public; Owner: sa
--

COPY public."laboratoryOrders_ordersample" (id, order_id, sample_id) FROM stdin;
\.
COPY public."laboratoryOrders_ordersample" (id, order_id, sample_id) FROM '$$PATH$$/3378.dat';

--
-- Data for Name: laboratoryOrders_ordertest; Type: TABLE DATA; Schema: public; Owner: sa
--

COPY public."laboratoryOrders_ordertest" (id, order_number_id, test_id_id) FROM stdin;
\.
COPY public."laboratoryOrders_ordertest" (id, order_number_id, test_id_id) FROM '$$PATH$$/3382.dat';

--
-- Data for Name: laboratoryOrders_sample; Type: TABLE DATA; Schema: public; Owner: sa
--

COPY public."laboratoryOrders_sample" (id, sample_type, sample_form, sop_number, lab_personel_id) FROM stdin;
\.
COPY public."laboratoryOrders_sample" (id, sample_type, sample_form, sop_number, lab_personel_id) FROM '$$PATH$$/3376.dat';

--
-- Data for Name: laboratoryOrders_testpackage; Type: TABLE DATA; Schema: public; Owner: sa
--

COPY public."laboratoryOrders_testpackage" (id, package_id, test_id) FROM stdin;
\.
COPY public."laboratoryOrders_testpackage" (id, package_id, test_id) FROM '$$PATH$$/3380.dat';

--
-- Data for Name: laboratoryOrders_testresult; Type: TABLE DATA; Schema: public; Owner: sa
--

COPY public."laboratoryOrders_testresult" (id, status, result, test_id_id) FROM stdin;
\.
COPY public."laboratoryOrders_testresult" (id, status, result, test_id_id) FROM '$$PATH$$/3374.dat';

--
-- Data for Name: laboratoryOrders_testsample; Type: TABLE DATA; Schema: public; Owner: sa
--

COPY public."laboratoryOrders_testsample" (id, lab_sample_id_id, test_id) FROM stdin;
\.
COPY public."laboratoryOrders_testsample" (id, lab_sample_id_id, test_id) FROM '$$PATH$$/3372.dat';

--
-- Data for Name: laboratory_instrument; Type: TABLE DATA; Schema: public; Owner: sa
--

COPY public.laboratory_instrument (id, type, location_id) FROM stdin;
\.
COPY public.laboratory_instrument (id, type, location_id) FROM '$$PATH$$/3360.dat';

--
-- Data for Name: laboratory_inventoryitem; Type: TABLE DATA; Schema: public; Owner: sa
--

COPY public.laboratory_inventoryitem (id, status, quantity_unit, usage_rate_unit, type, estimated_need, estimated_quantity, usage_rate) FROM stdin;
\.
COPY public.laboratory_inventoryitem (id, status, quantity_unit, usage_rate_unit, type, estimated_need, estimated_quantity, usage_rate) FROM '$$PATH$$/3362.dat';

--
-- Data for Name: laboratory_location; Type: TABLE DATA; Schema: public; Owner: sa
--

COPY public.laboratory_location (id, name, code) FROM stdin;
\.
COPY public.laboratory_location (id, name, code) FROM '$$PATH$$/3364.dat';

--
-- Data for Name: laboratory_test; Type: TABLE DATA; Schema: public; Owner: sa
--

COPY public.laboratory_test (id, name, code, cost, rush, time_taken, sample_type) FROM stdin;
\.
COPY public.laboratory_test (id, name, code, cost, rush, time_taken, sample_type) FROM '$$PATH$$/3366.dat';

--
-- Data for Name: laboratory_testinstrument; Type: TABLE DATA; Schema: public; Owner: sa
--

COPY public.laboratory_testinstrument (id, instrument_id, test_id_id) FROM stdin;
\.
COPY public.laboratory_testinstrument (id, instrument_id, test_id_id) FROM '$$PATH$$/3368.dat';

--
-- Data for Name: orders_order; Type: TABLE DATA; Schema: public; Owner: sa
--

COPY public.orders_order (id, account_number_id, order_number, submission_date) FROM stdin;
\.
COPY public.orders_order (id, account_number_id, order_number, submission_date) FROM '$$PATH$$/3356.dat';

--
-- Data for Name: orders_package; Type: TABLE DATA; Schema: public; Owner: sa
--

COPY public.orders_package (id, name) FROM stdin;
\.
COPY public.orders_package (id, name) FROM '$$PATH$$/3358.dat';

--
-- Data for Name: training_training; Type: TABLE DATA; Schema: public; Owner: sa
--

COPY public.training_training (id, name) FROM stdin;
\.
COPY public.training_training (id, name) FROM '$$PATH$$/3385.dat';

--
-- Data for Name: training_trainingattendence; Type: TABLE DATA; Schema: public; Owner: sa
--

COPY public.training_trainingattendence (id, attendee_id, training_instance_id) FROM stdin;
\.
COPY public.training_trainingattendence (id, attendee_id, training_instance_id) FROM '$$PATH$$/3389.dat';

--
-- Data for Name: training_trainingschedule; Type: TABLE DATA; Schema: public; Owner: sa
--

COPY public.training_trainingschedule (id, training_type_id, date_time) FROM stdin;
\.
COPY public.training_trainingschedule (id, training_type_id, date_time) FROM '$$PATH$$/3387.dat';

--
-- Name: accounts_client_id_seq; Type: SEQUENCE SET; Schema: public; Owner: sa
--

SELECT pg_catalog.setval('public.accounts_client_id_seq', 4, true);


--
-- Name: accounts_labadmin_id_seq; Type: SEQUENCE SET; Schema: public; Owner: sa
--

SELECT pg_catalog.setval('public.accounts_labadmin_id_seq', 3, true);


--
-- Name: accounts_labworker_id_seq; Type: SEQUENCE SET; Schema: public; Owner: sa
--

SELECT pg_catalog.setval('public.accounts_labworker_id_seq', 2, true);


--
-- Name: auth_group_id_seq; Type: SEQUENCE SET; Schema: public; Owner: sa
--

SELECT pg_catalog.setval('public.auth_group_id_seq', 4, true);


--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: sa
--

SELECT pg_catalog.setval('public.auth_group_permissions_id_seq', 137, true);


--
-- Name: auth_permission_id_seq; Type: SEQUENCE SET; Schema: public; Owner: sa
--

SELECT pg_catalog.setval('public.auth_permission_id_seq', 132, true);


--
-- Name: auth_user_groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: sa
--

SELECT pg_catalog.setval('public.auth_user_groups_id_seq', 3, true);


--
-- Name: auth_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: sa
--

SELECT pg_catalog.setval('public.auth_user_id_seq', 11, true);


--
-- Name: auth_user_user_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: sa
--

SELECT pg_catalog.setval('public.auth_user_user_permissions_id_seq', 1, false);


--
-- Name: django_admin_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: sa
--

SELECT pg_catalog.setval('public.django_admin_log_id_seq', 122, true);


--
-- Name: django_content_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: sa
--

SELECT pg_catalog.setval('public.django_content_type_id_seq', 33, true);


--
-- Name: django_migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: sa
--

SELECT pg_catalog.setval('public.django_migrations_id_seq', 67, true);


--
-- Name: laboratoryOrders_labsample_id_seq; Type: SEQUENCE SET; Schema: public; Owner: sa
--

SELECT pg_catalog.setval('public."laboratoryOrders_labsample_id_seq"', 1, false);


--
-- Name: laboratoryOrders_ordersample_id_seq; Type: SEQUENCE SET; Schema: public; Owner: sa
--

SELECT pg_catalog.setval('public."laboratoryOrders_ordersample_id_seq"', 1, false);


--
-- Name: laboratoryOrders_ordertest_id_seq; Type: SEQUENCE SET; Schema: public; Owner: sa
--

SELECT pg_catalog.setval('public."laboratoryOrders_ordertest_id_seq"', 1, false);


--
-- Name: laboratoryOrders_sample_id_seq; Type: SEQUENCE SET; Schema: public; Owner: sa
--

SELECT pg_catalog.setval('public."laboratoryOrders_sample_id_seq"', 1, false);


--
-- Name: laboratoryOrders_testpackage_id_seq; Type: SEQUENCE SET; Schema: public; Owner: sa
--

SELECT pg_catalog.setval('public."laboratoryOrders_testpackage_id_seq"', 1, false);


--
-- Name: laboratoryOrders_testresult_id_seq; Type: SEQUENCE SET; Schema: public; Owner: sa
--

SELECT pg_catalog.setval('public."laboratoryOrders_testresult_id_seq"', 1, false);


--
-- Name: laboratoryOrders_testsample_id_seq; Type: SEQUENCE SET; Schema: public; Owner: sa
--

SELECT pg_catalog.setval('public."laboratoryOrders_testsample_id_seq"', 1, false);


--
-- Name: laboratory_instrument_id_seq; Type: SEQUENCE SET; Schema: public; Owner: sa
--

SELECT pg_catalog.setval('public.laboratory_instrument_id_seq', 3, true);


--
-- Name: laboratory_inventoryitem_id_seq; Type: SEQUENCE SET; Schema: public; Owner: sa
--

SELECT pg_catalog.setval('public.laboratory_inventoryitem_id_seq', 2, true);


--
-- Name: laboratory_location_id_seq; Type: SEQUENCE SET; Schema: public; Owner: sa
--

SELECT pg_catalog.setval('public.laboratory_location_id_seq', 2, true);


--
-- Name: laboratory_test_id_seq; Type: SEQUENCE SET; Schema: public; Owner: sa
--

SELECT pg_catalog.setval('public.laboratory_test_id_seq', 5, true);


--
-- Name: laboratory_testinstrument_id_seq; Type: SEQUENCE SET; Schema: public; Owner: sa
--

SELECT pg_catalog.setval('public.laboratory_testinstrument_id_seq', 1, true);


--
-- Name: orders_order_id_seq; Type: SEQUENCE SET; Schema: public; Owner: sa
--

SELECT pg_catalog.setval('public.orders_order_id_seq', 3, true);


--
-- Name: orders_package_id_seq; Type: SEQUENCE SET; Schema: public; Owner: sa
--

SELECT pg_catalog.setval('public.orders_package_id_seq', 2, true);


--
-- Name: training_training_id_seq; Type: SEQUENCE SET; Schema: public; Owner: sa
--

SELECT pg_catalog.setval('public.training_training_id_seq', 1, false);


--
-- Name: training_trainingattendence_id_seq; Type: SEQUENCE SET; Schema: public; Owner: sa
--

SELECT pg_catalog.setval('public.training_trainingattendence_id_seq', 1, false);


--
-- Name: training_trainingschedule_id_seq; Type: SEQUENCE SET; Schema: public; Owner: sa
--

SELECT pg_catalog.setval('public.training_trainingschedule_id_seq', 1, false);


--
-- Name: accounts_client accounts_client_pkey; Type: CONSTRAINT; Schema: public; Owner: sa
--

ALTER TABLE ONLY public.accounts_client
    ADD CONSTRAINT accounts_client_pkey PRIMARY KEY (id);


--
-- Name: accounts_client accounts_client_user_id_key; Type: CONSTRAINT; Schema: public; Owner: sa
--

ALTER TABLE ONLY public.accounts_client
    ADD CONSTRAINT accounts_client_user_id_key UNIQUE (user_id);


--
-- Name: accounts_labadmin accounts_labadmin_pkey; Type: CONSTRAINT; Schema: public; Owner: sa
--

ALTER TABLE ONLY public.accounts_labadmin
    ADD CONSTRAINT accounts_labadmin_pkey PRIMARY KEY (id);


--
-- Name: accounts_labadmin accounts_labadmin_user_id_key; Type: CONSTRAINT; Schema: public; Owner: sa
--

ALTER TABLE ONLY public.accounts_labadmin
    ADD CONSTRAINT accounts_labadmin_user_id_key UNIQUE (user_id);


--
-- Name: accounts_labworker accounts_labworker_pkey; Type: CONSTRAINT; Schema: public; Owner: sa
--

ALTER TABLE ONLY public.accounts_labworker
    ADD CONSTRAINT accounts_labworker_pkey PRIMARY KEY (id);


--
-- Name: accounts_labworker accounts_labworker_user_id_key; Type: CONSTRAINT; Schema: public; Owner: sa
--

ALTER TABLE ONLY public.accounts_labworker
    ADD CONSTRAINT accounts_labworker_user_id_key UNIQUE (user_id);


--
-- Name: auth_group auth_group_name_key; Type: CONSTRAINT; Schema: public; Owner: sa
--

ALTER TABLE ONLY public.auth_group
    ADD CONSTRAINT auth_group_name_key UNIQUE (name);


--
-- Name: auth_group_permissions auth_group_permissions_group_id_permission_id_0cd325b0_uniq; Type: CONSTRAINT; Schema: public; Owner: sa
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_group_id_permission_id_0cd325b0_uniq UNIQUE (group_id, permission_id);


--
-- Name: auth_group_permissions auth_group_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: sa
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_pkey PRIMARY KEY (id);


--
-- Name: auth_group auth_group_pkey; Type: CONSTRAINT; Schema: public; Owner: sa
--

ALTER TABLE ONLY public.auth_group
    ADD CONSTRAINT auth_group_pkey PRIMARY KEY (id);


--
-- Name: auth_permission auth_permission_content_type_id_codename_01ab375a_uniq; Type: CONSTRAINT; Schema: public; Owner: sa
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_content_type_id_codename_01ab375a_uniq UNIQUE (content_type_id, codename);


--
-- Name: auth_permission auth_permission_pkey; Type: CONSTRAINT; Schema: public; Owner: sa
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_pkey PRIMARY KEY (id);


--
-- Name: auth_user_groups auth_user_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: sa
--

ALTER TABLE ONLY public.auth_user_groups
    ADD CONSTRAINT auth_user_groups_pkey PRIMARY KEY (id);


--
-- Name: auth_user_groups auth_user_groups_user_id_group_id_94350c0c_uniq; Type: CONSTRAINT; Schema: public; Owner: sa
--

ALTER TABLE ONLY public.auth_user_groups
    ADD CONSTRAINT auth_user_groups_user_id_group_id_94350c0c_uniq UNIQUE (user_id, group_id);


--
-- Name: auth_user auth_user_pkey; Type: CONSTRAINT; Schema: public; Owner: sa
--

ALTER TABLE ONLY public.auth_user
    ADD CONSTRAINT auth_user_pkey PRIMARY KEY (id);


--
-- Name: auth_user_user_permissions auth_user_user_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: sa
--

ALTER TABLE ONLY public.auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permissions_pkey PRIMARY KEY (id);


--
-- Name: auth_user_user_permissions auth_user_user_permissions_user_id_permission_id_14a6b632_uniq; Type: CONSTRAINT; Schema: public; Owner: sa
--

ALTER TABLE ONLY public.auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permissions_user_id_permission_id_14a6b632_uniq UNIQUE (user_id, permission_id);


--
-- Name: auth_user auth_user_username_key; Type: CONSTRAINT; Schema: public; Owner: sa
--

ALTER TABLE ONLY public.auth_user
    ADD CONSTRAINT auth_user_username_key UNIQUE (username);


--
-- Name: django_admin_log django_admin_log_pkey; Type: CONSTRAINT; Schema: public; Owner: sa
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_pkey PRIMARY KEY (id);


--
-- Name: django_content_type django_content_type_app_label_model_76bd3d3b_uniq; Type: CONSTRAINT; Schema: public; Owner: sa
--

ALTER TABLE ONLY public.django_content_type
    ADD CONSTRAINT django_content_type_app_label_model_76bd3d3b_uniq UNIQUE (app_label, model);


--
-- Name: django_content_type django_content_type_pkey; Type: CONSTRAINT; Schema: public; Owner: sa
--

ALTER TABLE ONLY public.django_content_type
    ADD CONSTRAINT django_content_type_pkey PRIMARY KEY (id);


--
-- Name: django_migrations django_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: sa
--

ALTER TABLE ONLY public.django_migrations
    ADD CONSTRAINT django_migrations_pkey PRIMARY KEY (id);


--
-- Name: django_session django_session_pkey; Type: CONSTRAINT; Schema: public; Owner: sa
--

ALTER TABLE ONLY public.django_session
    ADD CONSTRAINT django_session_pkey PRIMARY KEY (session_key);


--
-- Name: laboratoryOrders_labsample laboratoryOrders_labsample_pkey; Type: CONSTRAINT; Schema: public; Owner: sa
--

ALTER TABLE ONLY public."laboratoryOrders_labsample"
    ADD CONSTRAINT "laboratoryOrders_labsample_pkey" PRIMARY KEY (id);


--
-- Name: laboratoryOrders_ordersample laboratoryOrders_ordersample_pkey; Type: CONSTRAINT; Schema: public; Owner: sa
--

ALTER TABLE ONLY public."laboratoryOrders_ordersample"
    ADD CONSTRAINT "laboratoryOrders_ordersample_pkey" PRIMARY KEY (id);


--
-- Name: laboratoryOrders_ordertest laboratoryOrders_ordertest_pkey; Type: CONSTRAINT; Schema: public; Owner: sa
--

ALTER TABLE ONLY public."laboratoryOrders_ordertest"
    ADD CONSTRAINT "laboratoryOrders_ordertest_pkey" PRIMARY KEY (id);


--
-- Name: laboratoryOrders_sample laboratoryOrders_sample_pkey; Type: CONSTRAINT; Schema: public; Owner: sa
--

ALTER TABLE ONLY public."laboratoryOrders_sample"
    ADD CONSTRAINT "laboratoryOrders_sample_pkey" PRIMARY KEY (id);


--
-- Name: laboratoryOrders_testpackage laboratoryOrders_testpackage_pkey; Type: CONSTRAINT; Schema: public; Owner: sa
--

ALTER TABLE ONLY public."laboratoryOrders_testpackage"
    ADD CONSTRAINT "laboratoryOrders_testpackage_pkey" PRIMARY KEY (id);


--
-- Name: laboratoryOrders_testresult laboratoryOrders_testresult_pkey; Type: CONSTRAINT; Schema: public; Owner: sa
--

ALTER TABLE ONLY public."laboratoryOrders_testresult"
    ADD CONSTRAINT "laboratoryOrders_testresult_pkey" PRIMARY KEY (id);


--
-- Name: laboratoryOrders_testsample laboratoryOrders_testsample_pkey; Type: CONSTRAINT; Schema: public; Owner: sa
--

ALTER TABLE ONLY public."laboratoryOrders_testsample"
    ADD CONSTRAINT "laboratoryOrders_testsample_pkey" PRIMARY KEY (id);


--
-- Name: laboratory_instrument laboratory_instrument_pkey; Type: CONSTRAINT; Schema: public; Owner: sa
--

ALTER TABLE ONLY public.laboratory_instrument
    ADD CONSTRAINT laboratory_instrument_pkey PRIMARY KEY (id);


--
-- Name: laboratory_inventoryitem laboratory_inventoryitem_pkey; Type: CONSTRAINT; Schema: public; Owner: sa
--

ALTER TABLE ONLY public.laboratory_inventoryitem
    ADD CONSTRAINT laboratory_inventoryitem_pkey PRIMARY KEY (id);


--
-- Name: laboratory_location laboratory_location_pkey; Type: CONSTRAINT; Schema: public; Owner: sa
--

ALTER TABLE ONLY public.laboratory_location
    ADD CONSTRAINT laboratory_location_pkey PRIMARY KEY (id);


--
-- Name: laboratory_test laboratory_test_pkey; Type: CONSTRAINT; Schema: public; Owner: sa
--

ALTER TABLE ONLY public.laboratory_test
    ADD CONSTRAINT laboratory_test_pkey PRIMARY KEY (id);


--
-- Name: laboratory_testinstrument laboratory_testinstrument_pkey; Type: CONSTRAINT; Schema: public; Owner: sa
--

ALTER TABLE ONLY public.laboratory_testinstrument
    ADD CONSTRAINT laboratory_testinstrument_pkey PRIMARY KEY (id);


--
-- Name: orders_order orders_order_pkey; Type: CONSTRAINT; Schema: public; Owner: sa
--

ALTER TABLE ONLY public.orders_order
    ADD CONSTRAINT orders_order_pkey PRIMARY KEY (id);


--
-- Name: orders_package orders_package_pkey; Type: CONSTRAINT; Schema: public; Owner: sa
--

ALTER TABLE ONLY public.orders_package
    ADD CONSTRAINT orders_package_pkey PRIMARY KEY (id);


--
-- Name: training_training training_training_pkey; Type: CONSTRAINT; Schema: public; Owner: sa
--

ALTER TABLE ONLY public.training_training
    ADD CONSTRAINT training_training_pkey PRIMARY KEY (id);


--
-- Name: training_trainingattendence training_trainingattendence_pkey; Type: CONSTRAINT; Schema: public; Owner: sa
--

ALTER TABLE ONLY public.training_trainingattendence
    ADD CONSTRAINT training_trainingattendence_pkey PRIMARY KEY (id);


--
-- Name: training_trainingschedule training_trainingschedule_pkey; Type: CONSTRAINT; Schema: public; Owner: sa
--

ALTER TABLE ONLY public.training_trainingschedule
    ADD CONSTRAINT training_trainingschedule_pkey PRIMARY KEY (id);


--
-- Name: auth_group_name_a6ea08ec_like; Type: INDEX; Schema: public; Owner: sa
--

CREATE INDEX auth_group_name_a6ea08ec_like ON public.auth_group USING btree (name varchar_pattern_ops);


--
-- Name: auth_group_permissions_group_id_b120cbf9; Type: INDEX; Schema: public; Owner: sa
--

CREATE INDEX auth_group_permissions_group_id_b120cbf9 ON public.auth_group_permissions USING btree (group_id);


--
-- Name: auth_group_permissions_permission_id_84c5c92e; Type: INDEX; Schema: public; Owner: sa
--

CREATE INDEX auth_group_permissions_permission_id_84c5c92e ON public.auth_group_permissions USING btree (permission_id);


--
-- Name: auth_permission_content_type_id_2f476e4b; Type: INDEX; Schema: public; Owner: sa
--

CREATE INDEX auth_permission_content_type_id_2f476e4b ON public.auth_permission USING btree (content_type_id);


--
-- Name: auth_user_groups_group_id_97559544; Type: INDEX; Schema: public; Owner: sa
--

CREATE INDEX auth_user_groups_group_id_97559544 ON public.auth_user_groups USING btree (group_id);


--
-- Name: auth_user_groups_user_id_6a12ed8b; Type: INDEX; Schema: public; Owner: sa
--

CREATE INDEX auth_user_groups_user_id_6a12ed8b ON public.auth_user_groups USING btree (user_id);


--
-- Name: auth_user_user_permissions_permission_id_1fbb5f2c; Type: INDEX; Schema: public; Owner: sa
--

CREATE INDEX auth_user_user_permissions_permission_id_1fbb5f2c ON public.auth_user_user_permissions USING btree (permission_id);


--
-- Name: auth_user_user_permissions_user_id_a95ead1b; Type: INDEX; Schema: public; Owner: sa
--

CREATE INDEX auth_user_user_permissions_user_id_a95ead1b ON public.auth_user_user_permissions USING btree (user_id);


--
-- Name: auth_user_username_6821ab7c_like; Type: INDEX; Schema: public; Owner: sa
--

CREATE INDEX auth_user_username_6821ab7c_like ON public.auth_user USING btree (username varchar_pattern_ops);


--
-- Name: django_admin_log_content_type_id_c4bce8eb; Type: INDEX; Schema: public; Owner: sa
--

CREATE INDEX django_admin_log_content_type_id_c4bce8eb ON public.django_admin_log USING btree (content_type_id);


--
-- Name: django_admin_log_user_id_c564eba6; Type: INDEX; Schema: public; Owner: sa
--

CREATE INDEX django_admin_log_user_id_c564eba6 ON public.django_admin_log USING btree (user_id);


--
-- Name: django_session_expire_date_a5c62663; Type: INDEX; Schema: public; Owner: sa
--

CREATE INDEX django_session_expire_date_a5c62663 ON public.django_session USING btree (expire_date);


--
-- Name: django_session_session_key_c0390e0f_like; Type: INDEX; Schema: public; Owner: sa
--

CREATE INDEX django_session_session_key_c0390e0f_like ON public.django_session USING btree (session_key varchar_pattern_ops);


--
-- Name: laboratoryOrders_labsample_lab_location_id_6da02f48; Type: INDEX; Schema: public; Owner: sa
--

CREATE INDEX "laboratoryOrders_labsample_lab_location_id_6da02f48" ON public."laboratoryOrders_labsample" USING btree (lab_location_id);


--
-- Name: laboratoryOrders_labsample_sample_id_b7673012; Type: INDEX; Schema: public; Owner: sa
--

CREATE INDEX "laboratoryOrders_labsample_sample_id_b7673012" ON public."laboratoryOrders_labsample" USING btree (sample_id);


--
-- Name: laboratoryOrders_ordersample_order_id_bc86d9f1; Type: INDEX; Schema: public; Owner: sa
--

CREATE INDEX "laboratoryOrders_ordersample_order_id_bc86d9f1" ON public."laboratoryOrders_ordersample" USING btree (order_id);


--
-- Name: laboratoryOrders_ordersample_sample_id_eb7ad696; Type: INDEX; Schema: public; Owner: sa
--

CREATE INDEX "laboratoryOrders_ordersample_sample_id_eb7ad696" ON public."laboratoryOrders_ordersample" USING btree (sample_id);


--
-- Name: laboratoryOrders_ordertest_order_number_id_a9483c3c; Type: INDEX; Schema: public; Owner: sa
--

CREATE INDEX "laboratoryOrders_ordertest_order_number_id_a9483c3c" ON public."laboratoryOrders_ordertest" USING btree (order_number_id);


--
-- Name: laboratoryOrders_ordertest_test_id_id_14dd1d55; Type: INDEX; Schema: public; Owner: sa
--

CREATE INDEX "laboratoryOrders_ordertest_test_id_id_14dd1d55" ON public."laboratoryOrders_ordertest" USING btree (test_id_id);


--
-- Name: laboratoryOrders_sample_lab_personel_id_8cf85f02; Type: INDEX; Schema: public; Owner: sa
--

CREATE INDEX "laboratoryOrders_sample_lab_personel_id_8cf85f02" ON public."laboratoryOrders_sample" USING btree (lab_personel_id);


--
-- Name: laboratoryOrders_testpackage_package_id_98b57a90; Type: INDEX; Schema: public; Owner: sa
--

CREATE INDEX "laboratoryOrders_testpackage_package_id_98b57a90" ON public."laboratoryOrders_testpackage" USING btree (package_id);


--
-- Name: laboratoryOrders_testpackage_test_id_2c52975e; Type: INDEX; Schema: public; Owner: sa
--

CREATE INDEX "laboratoryOrders_testpackage_test_id_2c52975e" ON public."laboratoryOrders_testpackage" USING btree (test_id);


--
-- Name: laboratoryOrders_testresult_test_id_id_ce71f0c4; Type: INDEX; Schema: public; Owner: sa
--

CREATE INDEX "laboratoryOrders_testresult_test_id_id_ce71f0c4" ON public."laboratoryOrders_testresult" USING btree (test_id_id);


--
-- Name: laboratoryOrders_testsample_lab_sample_id_id_deb948c0; Type: INDEX; Schema: public; Owner: sa
--

CREATE INDEX "laboratoryOrders_testsample_lab_sample_id_id_deb948c0" ON public."laboratoryOrders_testsample" USING btree (lab_sample_id_id);


--
-- Name: laboratoryOrders_testsample_test_id_e83b5905; Type: INDEX; Schema: public; Owner: sa
--

CREATE INDEX "laboratoryOrders_testsample_test_id_e83b5905" ON public."laboratoryOrders_testsample" USING btree (test_id);


--
-- Name: laboratory_instrument_location_id_64e21603; Type: INDEX; Schema: public; Owner: sa
--

CREATE INDEX laboratory_instrument_location_id_64e21603 ON public.laboratory_instrument USING btree (location_id);


--
-- Name: laboratory_testinstrument_instrument_id_ce5ba333; Type: INDEX; Schema: public; Owner: sa
--

CREATE INDEX laboratory_testinstrument_instrument_id_ce5ba333 ON public.laboratory_testinstrument USING btree (instrument_id);


--
-- Name: laboratory_testinstrument_test_id_id_3de7b580; Type: INDEX; Schema: public; Owner: sa
--

CREATE INDEX laboratory_testinstrument_test_id_id_3de7b580 ON public.laboratory_testinstrument USING btree (test_id_id);


--
-- Name: orders_order_account_number_id_9d741526; Type: INDEX; Schema: public; Owner: sa
--

CREATE INDEX orders_order_account_number_id_9d741526 ON public.orders_order USING btree (account_number_id);


--
-- Name: training_trainingattendence_attendee_id_0ee3c58f; Type: INDEX; Schema: public; Owner: sa
--

CREATE INDEX training_trainingattendence_attendee_id_0ee3c58f ON public.training_trainingattendence USING btree (attendee_id);


--
-- Name: training_trainingattendence_training_instance_id_98164e6f; Type: INDEX; Schema: public; Owner: sa
--

CREATE INDEX training_trainingattendence_training_instance_id_98164e6f ON public.training_trainingattendence USING btree (training_instance_id);


--
-- Name: training_trainingschedule_training_type_id_6ba737cd; Type: INDEX; Schema: public; Owner: sa
--

CREATE INDEX training_trainingschedule_training_type_id_6ba737cd ON public.training_trainingschedule USING btree (training_type_id);


--
-- Name: accounts_client accounts_client_user_id_0e07a191_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: sa
--

ALTER TABLE ONLY public.accounts_client
    ADD CONSTRAINT accounts_client_user_id_0e07a191_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: accounts_labadmin accounts_labadmin_user_id_3915c6c8_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: sa
--

ALTER TABLE ONLY public.accounts_labadmin
    ADD CONSTRAINT accounts_labadmin_user_id_3915c6c8_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: accounts_labworker accounts_labworker_user_id_c9501627_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: sa
--

ALTER TABLE ONLY public.accounts_labworker
    ADD CONSTRAINT accounts_labworker_user_id_c9501627_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_group_permissions auth_group_permissio_permission_id_84c5c92e_fk_auth_perm; Type: FK CONSTRAINT; Schema: public; Owner: sa
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissio_permission_id_84c5c92e_fk_auth_perm FOREIGN KEY (permission_id) REFERENCES public.auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_group_permissions auth_group_permissions_group_id_b120cbf9_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: sa
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_group_id_b120cbf9_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES public.auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_permission auth_permission_content_type_id_2f476e4b_fk_django_co; Type: FK CONSTRAINT; Schema: public; Owner: sa
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_content_type_id_2f476e4b_fk_django_co FOREIGN KEY (content_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_groups auth_user_groups_group_id_97559544_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: sa
--

ALTER TABLE ONLY public.auth_user_groups
    ADD CONSTRAINT auth_user_groups_group_id_97559544_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES public.auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_groups auth_user_groups_user_id_6a12ed8b_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: sa
--

ALTER TABLE ONLY public.auth_user_groups
    ADD CONSTRAINT auth_user_groups_user_id_6a12ed8b_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_user_permissions auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm; Type: FK CONSTRAINT; Schema: public; Owner: sa
--

ALTER TABLE ONLY public.auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm FOREIGN KEY (permission_id) REFERENCES public.auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_user_permissions auth_user_user_permissions_user_id_a95ead1b_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: sa
--

ALTER TABLE ONLY public.auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permissions_user_id_a95ead1b_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_admin_log django_admin_log_content_type_id_c4bce8eb_fk_django_co; Type: FK CONSTRAINT; Schema: public; Owner: sa
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_content_type_id_c4bce8eb_fk_django_co FOREIGN KEY (content_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_admin_log django_admin_log_user_id_c564eba6_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: sa
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_user_id_c564eba6_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: laboratoryOrders_labsample laboratoryOrders_lab_lab_location_id_6da02f48_fk_laborator; Type: FK CONSTRAINT; Schema: public; Owner: sa
--

ALTER TABLE ONLY public."laboratoryOrders_labsample"
    ADD CONSTRAINT "laboratoryOrders_lab_lab_location_id_6da02f48_fk_laborator" FOREIGN KEY (lab_location_id) REFERENCES public.laboratory_location(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: laboratoryOrders_labsample laboratoryOrders_lab_sample_id_b7673012_fk_laborator; Type: FK CONSTRAINT; Schema: public; Owner: sa
--

ALTER TABLE ONLY public."laboratoryOrders_labsample"
    ADD CONSTRAINT "laboratoryOrders_lab_sample_id_b7673012_fk_laborator" FOREIGN KEY (sample_id) REFERENCES public."laboratoryOrders_sample"(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: laboratoryOrders_ordersample laboratoryOrders_ord_order_id_bc86d9f1_fk_orders_or; Type: FK CONSTRAINT; Schema: public; Owner: sa
--

ALTER TABLE ONLY public."laboratoryOrders_ordersample"
    ADD CONSTRAINT "laboratoryOrders_ord_order_id_bc86d9f1_fk_orders_or" FOREIGN KEY (order_id) REFERENCES public.orders_order(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: laboratoryOrders_ordertest laboratoryOrders_ord_order_number_id_a9483c3c_fk_orders_or; Type: FK CONSTRAINT; Schema: public; Owner: sa
--

ALTER TABLE ONLY public."laboratoryOrders_ordertest"
    ADD CONSTRAINT "laboratoryOrders_ord_order_number_id_a9483c3c_fk_orders_or" FOREIGN KEY (order_number_id) REFERENCES public.orders_order(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: laboratoryOrders_ordersample laboratoryOrders_ord_sample_id_eb7ad696_fk_laborator; Type: FK CONSTRAINT; Schema: public; Owner: sa
--

ALTER TABLE ONLY public."laboratoryOrders_ordersample"
    ADD CONSTRAINT "laboratoryOrders_ord_sample_id_eb7ad696_fk_laborator" FOREIGN KEY (sample_id) REFERENCES public."laboratoryOrders_sample"(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: laboratoryOrders_ordertest laboratoryOrders_ord_test_id_id_14dd1d55_fk_laborator; Type: FK CONSTRAINT; Schema: public; Owner: sa
--

ALTER TABLE ONLY public."laboratoryOrders_ordertest"
    ADD CONSTRAINT "laboratoryOrders_ord_test_id_id_14dd1d55_fk_laborator" FOREIGN KEY (test_id_id) REFERENCES public.laboratory_test(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: laboratoryOrders_sample laboratoryOrders_sam_lab_personel_id_8cf85f02_fk_accounts_; Type: FK CONSTRAINT; Schema: public; Owner: sa
--

ALTER TABLE ONLY public."laboratoryOrders_sample"
    ADD CONSTRAINT "laboratoryOrders_sam_lab_personel_id_8cf85f02_fk_accounts_" FOREIGN KEY (lab_personel_id) REFERENCES public.accounts_labworker(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: laboratoryOrders_testsample laboratoryOrders_tes_lab_sample_id_id_deb948c0_fk_laborator; Type: FK CONSTRAINT; Schema: public; Owner: sa
--

ALTER TABLE ONLY public."laboratoryOrders_testsample"
    ADD CONSTRAINT "laboratoryOrders_tes_lab_sample_id_id_deb948c0_fk_laborator" FOREIGN KEY (lab_sample_id_id) REFERENCES public."laboratoryOrders_labsample"(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: laboratoryOrders_testpackage laboratoryOrders_tes_package_id_98b57a90_fk_orders_pa; Type: FK CONSTRAINT; Schema: public; Owner: sa
--

ALTER TABLE ONLY public."laboratoryOrders_testpackage"
    ADD CONSTRAINT "laboratoryOrders_tes_package_id_98b57a90_fk_orders_pa" FOREIGN KEY (package_id) REFERENCES public.orders_package(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: laboratoryOrders_testpackage laboratoryOrders_tes_test_id_2c52975e_fk_laborator; Type: FK CONSTRAINT; Schema: public; Owner: sa
--

ALTER TABLE ONLY public."laboratoryOrders_testpackage"
    ADD CONSTRAINT "laboratoryOrders_tes_test_id_2c52975e_fk_laborator" FOREIGN KEY (test_id) REFERENCES public.laboratory_test(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: laboratoryOrders_testsample laboratoryOrders_tes_test_id_e83b5905_fk_laborator; Type: FK CONSTRAINT; Schema: public; Owner: sa
--

ALTER TABLE ONLY public."laboratoryOrders_testsample"
    ADD CONSTRAINT "laboratoryOrders_tes_test_id_e83b5905_fk_laborator" FOREIGN KEY (test_id) REFERENCES public.laboratory_test(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: laboratoryOrders_testresult laboratoryOrders_tes_test_id_id_ce71f0c4_fk_laborator; Type: FK CONSTRAINT; Schema: public; Owner: sa
--

ALTER TABLE ONLY public."laboratoryOrders_testresult"
    ADD CONSTRAINT "laboratoryOrders_tes_test_id_id_ce71f0c4_fk_laborator" FOREIGN KEY (test_id_id) REFERENCES public."laboratoryOrders_testsample"(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: laboratory_instrument laboratory_instrumen_location_id_64e21603_fk_laborator; Type: FK CONSTRAINT; Schema: public; Owner: sa
--

ALTER TABLE ONLY public.laboratory_instrument
    ADD CONSTRAINT laboratory_instrumen_location_id_64e21603_fk_laborator FOREIGN KEY (location_id) REFERENCES public.laboratory_location(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: laboratory_testinstrument laboratory_testinstr_instrument_id_ce5ba333_fk_laborator; Type: FK CONSTRAINT; Schema: public; Owner: sa
--

ALTER TABLE ONLY public.laboratory_testinstrument
    ADD CONSTRAINT laboratory_testinstr_instrument_id_ce5ba333_fk_laborator FOREIGN KEY (instrument_id) REFERENCES public.laboratory_instrument(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: laboratory_testinstrument laboratory_testinstr_test_id_id_3de7b580_fk_laborator; Type: FK CONSTRAINT; Schema: public; Owner: sa
--

ALTER TABLE ONLY public.laboratory_testinstrument
    ADD CONSTRAINT laboratory_testinstr_test_id_id_3de7b580_fk_laborator FOREIGN KEY (test_id_id) REFERENCES public.laboratory_test(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: orders_order orders_order_account_number_id_9d741526_fk_accounts_client_id; Type: FK CONSTRAINT; Schema: public; Owner: sa
--

ALTER TABLE ONLY public.orders_order
    ADD CONSTRAINT orders_order_account_number_id_9d741526_fk_accounts_client_id FOREIGN KEY (account_number_id) REFERENCES public.accounts_client(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: training_trainingattendence training_trainingatt_attendee_id_0ee3c58f_fk_accounts_; Type: FK CONSTRAINT; Schema: public; Owner: sa
--

ALTER TABLE ONLY public.training_trainingattendence
    ADD CONSTRAINT training_trainingatt_attendee_id_0ee3c58f_fk_accounts_ FOREIGN KEY (attendee_id) REFERENCES public.accounts_labworker(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: training_trainingattendence training_trainingatt_training_instance_id_98164e6f_fk_training_; Type: FK CONSTRAINT; Schema: public; Owner: sa
--

ALTER TABLE ONLY public.training_trainingattendence
    ADD CONSTRAINT training_trainingatt_training_instance_id_98164e6f_fk_training_ FOREIGN KEY (training_instance_id) REFERENCES public.training_trainingschedule(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: training_trainingschedule training_trainingsch_training_type_id_6ba737cd_fk_training_; Type: FK CONSTRAINT; Schema: public; Owner: sa
--

ALTER TABLE ONLY public.training_trainingschedule
    ADD CONSTRAINT training_trainingsch_training_type_id_6ba737cd_fk_training_ FOREIGN KEY (training_type_id) REFERENCES public.training_training(id) DEFERRABLE INITIALLY DEFERRED;


--
-- PostgreSQL database dump complete
--

